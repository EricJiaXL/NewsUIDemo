//
//  ViewController.m
//  EJNewsUIDemo
//
//  Created by 贾晓磊 on 16/11/29.
//  Copyright © 2016年 贾晓磊. All rights reserved.
//

#import "ViewController.h"
#import "EJSubViewController.h"
@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    self.title = @"News";
    
    for (int i = 0; i < 10; i++) {
        EJSubViewController* sub = [[EJSubViewController alloc] init];
        sub.title = [NSString stringWithFormat:@"title%i", i];
        [self addChildViewController:sub];
    }

    //If you want to change the UI,You can check the APIs in "YHSwayViewController.h", and keyin code here.
    
    [super viewDidLoad];
    
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
