//
//  ViewController.h
//  EJNewsUIDemo
//
//  Created by 贾晓磊 on 16/11/29.
//  Copyright © 2016年 贾晓磊. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "EJNewsViewController.h"
@interface ViewController : EJNewsViewController


@end

