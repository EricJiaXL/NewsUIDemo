//
//  EJNewsButton.h
//  EJNewsUIDemo
//
//  Created by 贾晓磊 on 16/11/29.
//  Copyright © 2016年 贾晓磊. All rights reserved.
//

#import "EJNewsButton.h"
#import "UIColor+RGB.h"

static const CGFloat defaultNormalSize = 14.0f;
static const CGFloat defaultSelectSize = 20.0f;

static const int defaultNormalRed = 0xb6;
static const int defaultNormalGreen = 0xb6;
static const int defaultNormalBlue = 0xb6;

static const int defaultSelectedRed = 0xff;
static const int defaultSelectedGreen = 0xff;
static const int defaultSelectedBlue = 0xff;

#define kColor(r, g, b) [UIColor colorWithRed:(r) / 255.0 green:(g) / 255.0 blue:(b) / 255.0 alpha:1.0]

@interface EJNewsButton ()
@property (nonatomic, assign) int red;
@property (nonatomic, assign) int green;
@property (nonatomic, assign) int blue;
@end

@implementation EJNewsButton

- (instancetype)initWithFrame:(CGRect)frame
{
    if (self = [super initWithFrame:frame]) {

        if (!self.newsButtonNormalColor) {
            self.newsButtonNormalColor = kColor(defaultNormalRed, defaultNormalGreen, defaultNormalBlue);
        }

        if (!self.newsButtonSelectedColor) {
            self.newsButtonSelectedColor = kColor(defaultSelectedRed, defaultSelectedGreen, defaultSelectedBlue);
        }

        if (!self.newsButtonNormalSize) {
            self.newsButtonNormalSize = defaultNormalSize;
        }

        if (!self.newsButtonSelectedSize) {
            self.newsButtonSelectedSize = defaultSelectSize;
        }

        self.red = self.newsButtonNormalColor.r;
        self.green = self.newsButtonNormalColor.g;
        self.blue = self.newsButtonNormalColor.b;

        [self setTitleColor:kColor(self.red, self.green, self.blue) forState:UIControlStateNormal];

        self.titleLabel.font = [UIFont systemFontOfSize:self.newsButtonNormalSize];
    }
    return self;
}

- (void)setSelected:(BOOL)selected
{
    [super setSelected:selected];

    self.titleLabel.font = [UIFont systemFontOfSize:selected ? self.newsButtonSelectedSize : self.newsButtonNormalSize];

    if (selected) {

        self.red = self.newsButtonSelectedColor.r;
        self.green = self.newsButtonSelectedColor.g;
        self.blue = self.newsButtonSelectedColor.b;
    }
    else {
        self.red = self.newsButtonNormalColor.r;
        self.green = self.newsButtonNormalColor.g;
        self.blue = self.newsButtonNormalColor.b;
    }

    [self setTitleColor:kColor(self.red, self.green, self.blue) forState:UIControlStateSelected];
}

- (void)setScale:(CGFloat)percent
{
    // 调整文字大小
    CGFloat size = self.newsButtonNormalSize + (self.newsButtonSelectedSize - self.newsButtonNormalSize) * percent;
    self.titleLabel.font = [UIFont systemFontOfSize:size];

    // 调整颜色
    self.red = self.newsButtonNormalColor.r + (self.newsButtonSelectedColor.r - self.newsButtonNormalColor.r) * percent;
    self.green = self.newsButtonNormalColor.g + (self.newsButtonSelectedColor.g - self.newsButtonNormalColor.g) * percent;
    self.blue = self.newsButtonNormalColor.b + (self.newsButtonSelectedColor.b - self.newsButtonNormalColor.b) * percent;

    [self setTitleColor:kColor(self.red, self.green, self.blue) forState:UIControlStateNormal];
    [self setTitleColor:kColor(self.red, self.green, self.blue) forState:UIControlStateSelected];
}

@end
