//
//  EJNewsViewController.m
//  EJNewsUIDemo
//
//  Created by 贾晓磊 on 16/11/29.
//  Copyright © 2016年 贾晓磊. All rights reserved.
//

#import "EJNewsViewController.h"
#import "EJNewsButton.h"

#define kScreenWidth [UIScreen mainScreen].bounds.size.width
#define kScreenHeight [UIScreen mainScreen].bounds.size.height

#define kViewWidth(view) view.frame.size.width
#define kViewHeight(view) view.frame.size.height

@interface EJNewsViewController () <UIScrollViewDelegate>

@property (weak, nonatomic) UIScrollView* labelsScrollView;
@property (weak, nonatomic) UIScrollView* contentsScrollView;

@property (weak, nonatomic) EJNewsButton* selectedButton;

@end

@implementation EJNewsViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.

    [self initView];
}

/**
 *  初始化view
 */
- (void)initView
{
    self.automaticallyAdjustsScrollViewInsets = NO;
    // 初始化标题的scrollview
    UIScrollView* labelsScrollView = [[UIScrollView alloc] init];
    CGFloat labelsY = [self.parentViewController isKindOfClass:[UINavigationController class]] ? 20 + 44 : 20;
    CGFloat labelsH = self.newsTitleViewHeight ? self.newsTitleViewHeight : 40;
    labelsScrollView.frame = CGRectMake(0, labelsY, kScreenWidth, labelsH);
    self.labelsScrollView = labelsScrollView;
    UIColor* titleBgColor = self.newsTitleViewBackgroundColor ? self.newsTitleViewBackgroundColor : [UIColor grayColor];
    self.labelsScrollView.backgroundColor = titleBgColor;
    [self.view addSubview:self.labelsScrollView];

    // 初始化内容的scrollview
    UIScrollView* contentsScrollView = [[UIScrollView alloc] init];
    contentsScrollView.frame = CGRectMake(0, CGRectGetMaxY(self.labelsScrollView.frame), kScreenWidth, kScreenHeight - CGRectGetMaxY(self.labelsScrollView.frame));
    contentsScrollView.pagingEnabled = YES;
    contentsScrollView.showsHorizontalScrollIndicator = NO;
    self.contentsScrollView = contentsScrollView;
    UIColor* contentBgColor = self.newsContentViewBackgroundColor ? self.newsContentViewBackgroundColor : [UIColor whiteColor];
    self.contentsScrollView.backgroundColor = contentBgColor;
    [self.view addSubview:self.contentsScrollView];

    EJNewsButton* tempBtn;
    CGFloat labelButtonW = self.newsTitleViewButtonWidth ? self.newsTitleViewButtonWidth : 90;
    NSUInteger count = self.childViewControllers.count;
    for (NSUInteger i = 0; i < count; i++) {
        // 取出i位置对应的子控制器
        UIViewController* childVc = self.childViewControllers[i];

        // 添加标签
        EJNewsButton* labelButton = [[EJNewsButton alloc] init];
        if (self.newsTitleViewButtonNormalColor) {
            [labelButton setTitleColor:self.newsTitleViewButtonNormalColor forState:UIControlStateNormal];
            labelButton.newsButtonNormalColor = self.newsTitleViewButtonNormalColor;
        }

        if (self.newsTitleViewButtonSelectedColor) {
            [labelButton setTitleColor:self.newsTitleViewButtonSelectedColor forState:UIControlStateSelected];
            labelButton.newsButtonSelectedColor = self.newsTitleViewButtonSelectedColor;
        }

        if (self.newsTitleViewButtonNormalSize) {
            labelButton.titleLabel.font = [UIFont systemFontOfSize:self.newsTitleViewButtonNormalSize];
            labelButton.newsButtonNormalSize = self.newsTitleViewButtonNormalSize;
        }

        if (self.newsTitleViewButtonSelectedSize) {
            labelButton.titleLabel.font = [UIFont systemFontOfSize:self.newsTitleViewButtonSelectedSize];
            labelButton.newsButtonSelectedSize = self.newsTitleViewButtonSelectedSize;
        }

        labelButton.frame = CGRectMake(i * labelButtonW, 0, labelButtonW, kViewHeight(self.labelsScrollView));
        // 如果设置了title就用title 如果没有则默认显示title
        NSString* labelTitle = [childVc.title stringByReplacingOccurrencesOfString:@" " withString:@""].length ? childVc.title : @"title";

        [labelButton setTitle:labelTitle forState:UIControlStateNormal];
        [labelButton addTarget:self action:@selector(labelClick:) forControlEvents:UIControlEventTouchUpInside];
        [self.labelsScrollView addSubview:labelButton];

        // 保存第一个按钮
        i == 0 ? tempBtn = labelButton : nil;
    }

    // 设置内容大小
    self.labelsScrollView.contentSize = CGSizeMake(count * labelButtonW, 0);
    self.contentsScrollView.contentSize = CGSizeMake(count * kScreenWidth, 0);

    self.contentsScrollView.delegate = self;

    [self labelClick:tempBtn];
}

/**
 *  点击按钮执行的事件
 *
 *  @param labelButton 点击的按钮
 */
- (void)labelClick:(EJNewsButton*)labelButton
{
    // 切换按钮状态
    self.selectedButton.selected = NO;
    labelButton.selected = YES;
    self.selectedButton = labelButton;

    NSUInteger index = [self.labelsScrollView.subviews indexOfObject:labelButton];
    // 添加子控制器
    [self addChildVc:index];
    // 切换子控制器
    [self switchChildVc:index];
}

/**
 *  添加index位置对应的控制器
 *
 *  @param index 下标
 */
- (void)addChildVc:(NSUInteger)index
{
    UIViewController* newChildVc = self.childViewControllers[index];
    if (newChildVc.view.superview == nil) {
        newChildVc.view.frame = CGRectMake(index * kViewWidth(self.contentsScrollView), 0, kViewWidth(self.contentsScrollView), kViewHeight(self.contentsScrollView));
        [self.contentsScrollView addSubview:newChildVc.view];
    }
}

/**
 *  切换子控制器
 *
 *  @param index 子控制器对应的索引
 */
- (void)switchChildVc:(NSUInteger)index
{

    // 滚动到index控制器对应的位置
    [self.contentsScrollView setContentOffset:CGPointMake(index * kViewWidth(self.contentsScrollView), 0) animated:YES];

    // 让被点击的标签按钮显示在最中间
    CGFloat offsetX = CGRectGetMinX(self.selectedButton.frame) + kViewWidth(self.selectedButton) * 0.5 - kViewWidth(self.labelsScrollView) * 0.5;
    CGFloat maxOffsetX = self.labelsScrollView.contentSize.width - kViewWidth(self.labelsScrollView);

    //    if (offsetX < 0) {
    //        offsetX = 0;
    //    }
    //    else if (offsetX > maxOffsetX) {
    //        offsetX = maxOffsetX;
    //    }
    // 等价
    offsetX = offsetX < 0 ? 0 : offsetX > maxOffsetX ? maxOffsetX : offsetX;

    CGPoint offset = CGPointMake(offsetX, 0);
    [self.labelsScrollView setContentOffset:offset animated:YES];
}

#pragma mark - <UIScrollViewDelegate>

/**
 *  当scrollView减速完毕时调用
 */
- (void)scrollViewDidEndDecelerating:(UIScrollView*)scrollView
{
    NSUInteger index = scrollView.contentOffset.x / kViewWidth(scrollView);
    EJNewsButton* labelButton = self.labelsScrollView.subviews[index];
    [self labelClick:labelButton];
}

/**
 *  当scrollView正在滚动时调用
 */
- (void)scrollViewDidScroll:(UIScrollView*)scrollView
{
    CGFloat value = scrollView.contentOffset.x / kViewWidth(scrollView);
    NSUInteger oneIndex = value;
    NSUInteger twoIndex = oneIndex + 1;
    CGFloat twoPercent = value - oneIndex;
    CGFloat onePercent = 1 - twoPercent;

    if ([self.labelsScrollView.subviews[oneIndex] class] == [EJNewsButton class]) {
        EJNewsButton* oneButton = self.labelsScrollView.subviews[oneIndex];
        [oneButton setScale:onePercent];
    }

    if ([self.labelsScrollView.subviews[twoIndex] class] == [EJNewsButton class]) {
        EJNewsButton* twoButton = self.labelsScrollView.subviews[twoIndex];
        [twoButton setScale:twoPercent];
    }

    // 预加载下一个页面
    NSUInteger index = self.contentsScrollView.contentOffset.x / kScreenWidth + 1;
    if (index + 1 <= self.childViewControllers.count) {
        [self addChildVc:index];
    }
}

@end
