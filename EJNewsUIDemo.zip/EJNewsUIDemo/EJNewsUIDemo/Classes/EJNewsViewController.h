//
//  EJNewsViewController.h
//  EJNewsUIDemo
//
//  Created by 贾晓磊 on 16/11/29.
//  Copyright © 2016年 贾晓磊. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface EJNewsViewController : UIViewController

/**
 *  标题view未选中的颜色
 */
@property (strong, nonatomic) UIColor* newsTitleViewButtonNormalColor;

/**
 *  标题view选中的颜色
 */
@property (strong, nonatomic) UIColor* newsTitleViewButtonSelectedColor;

/**
 *  标题view未选中时的字号大小
 */
@property (assign, nonatomic) CGFloat newsTitleViewButtonNormalSize;

/**
 *  标题view选中时的字号大小
 */
@property (assign, nonatomic) CGFloat newsTitleViewButtonSelectedSize;

/**
 *  标题view中按钮的宽度
 */
@property (assign, nonatomic) CGFloat newsTitleViewButtonWidth;

/**
 *  标题view的高度
 */
@property (assign, nonatomic) CGFloat newsTitleViewHeight;

/**
 *  标题view的背景色
 */
@property (strong, nonatomic) UIColor* newsTitleViewBackgroundColor;

/**
 *  内容view的背景色
 */
@property (strong, nonatomic) UIColor* newsContentViewBackgroundColor;

@end
