//
//  EJNewsButton.h
//  EJNewsUIDemo
//
//  Created by 贾晓磊 on 16/11/29.
//  Copyright © 2016年 贾晓磊. All rights reserved.
//


#import <UIKit/UIKit.h>

@interface EJNewsButton : UIButton

@property (strong, nonatomic) UIColor* newsButtonNormalColor;
@property (strong, nonatomic) UIColor* newsButtonSelectedColor;

@property (assign, nonatomic) CGFloat newsButtonNormalSize;
@property (assign, nonatomic) CGFloat newsButtonSelectedSize;

/**
 *  传入一个百分值来调整按钮内部的细节
 *
 *  @param percent 按钮占据的百分比
 */
- (void)setScale:(CGFloat)percent;

@end
