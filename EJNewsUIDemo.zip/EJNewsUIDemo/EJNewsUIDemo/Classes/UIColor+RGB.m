//
//  UIColor+RGB.m
//  EJNewsUIDemo
//
//  Created by 贾晓磊 on 16/11/29.
//  Copyright © 2016年 贾晓磊. All rights reserved.
//

#import "UIColor+RGB.h"

@implementation UIColor (RGB)

- (NSArray*)arrayWithColor
{
    CGFloat r = 0, g = 0, b = 0, a = 0;

    if ([self respondsToSelector:@selector(getRed:green:blue:alpha:)]) {
        [self getRed:&r green:&g blue:&b alpha:&a];
    }
    else {
        const CGFloat* components = CGColorGetComponents(self.CGColor);
        r = components[0];
        g = components[1];
        b = components[2];
        a = components[3];
    }

    return @[ @(r), @(g), @(b), @(a) ];
}

- (int)r
{
    return [[[self arrayWithColor] objectAtIndex:0] floatValue] * 255.0;
}

- (int)g
{
    return [[[self arrayWithColor] objectAtIndex:1] floatValue] * 255.0;
}

- (int)b
{
    return [[[self arrayWithColor] objectAtIndex:2] floatValue] * 255.0;
}
@end
